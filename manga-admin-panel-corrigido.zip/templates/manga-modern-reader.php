<?php
/**
 * Template para o leitor de mangá moderno
 * Suporta ajuste de brilho e opções de visualização (página ou lista corrida)
 */

// Verificação de segurança
if (!defined('ABSPATH')) {
    exit;
}

// Verificar se temos os parâmetros necessários
if (!isset($manga_id) || !$manga_id) {
    echo '<div class="manga-alert manga-alert-danger">';
    echo esc_html__('ID do mangá não fornecido.', 'manga-admin-panel');
    echo '</div>';
    return;
}

// Obter informações do mangá
$manga_title = get_the_title($manga_id);
$manga_permalink = get_permalink($manga_id);
$manga_thumbnail = get_the_post_thumbnail_url($manga_id, 'medium');

// Verificar se está no modo de leitura de capítulo
if (!isset($chapter_id) || !$chapter_id) {
    // Se não temos chapter_id, redirecionar para a lista de capítulos
    include MANGA_ADMIN_PANEL_PATH . 'templates/manga-chapter-list.php';
    return;
}

// Obter informações do capítulo - função simulada para desenvolvimento
function get_chapter_data($manga_id, $chapter_id) {
    // Em uma implementação real, isso obteria os dados do capítulo do banco de dados
    
    // Gerar dados de exemplo para o capítulo
    $chapter_name = 'Capítulo ' . $chapter_id;
    $chapter_number = $chapter_id;
    
    // Gerar páginas de exemplo
    $pages = array();
    $total_pages = 10; // Número aleatório de páginas entre 5 e 15
    
    for ($i = 1; $i <= $total_pages; $i++) {
        $pages[] = array(
            'id' => $i,
            'url' => 'https://via.placeholder.com/800x1200.png?text=Página+' . $i,
            'alt' => sprintf(__('Página %d', 'manga-admin-panel'), $i)
        );
    }
    
    // Estrutura de dados do capítulo
    return array(
        'id' => $chapter_id,
        'name' => $chapter_name,
        'number' => $chapter_number,
        'pages' => $pages,
        'prev_chapter' => ($chapter_id > 1) ? $chapter_id - 1 : null,
        'next_chapter' => $chapter_id + 1,
        'date' => date('Y-m-d H:i:s', time() - ($chapter_id * 86400)), // Data simulada (mais antiga para capítulos menores)
        'is_premium' => ($chapter_id % 5 === 0), // Capítulos múltiplos de 5 são premium (para simulação)
    );
}

// Obter dados do capítulo
$chapter_data = get_chapter_data($manga_id, $chapter_id);

// Verificar preferências do usuário
$user_view_mode = isset($_COOKIE['manga_reader_view_mode']) ? sanitize_text_field($_COOKIE['manga_reader_view_mode']) : 'pagination';
$user_brightness = isset($_COOKIE['manga_reader_brightness']) ? intval($_COOKIE['manga_reader_brightness']) : 100;

// Usar modo de visualização do shortcode, se fornecido
if (isset($default_mode) && in_array($default_mode, array('pagination', 'webtoon'))) {
    $user_view_mode = $default_mode;
}

// Obter lista de capítulos para seletor
function get_manga_chapters_for_select($manga_id, $current_chapter_id) {
    // Em uma implementação real, isso obteria a lista de capítulos do banco de dados
    
    // Gerar lista simulada de capítulos
    $chapters = array();
    $max_chapters = 20; // Número máximo de capítulos para simulação
    
    for ($i = 1; $i <= $max_chapters; $i++) {
        $chapters[] = array(
            'id' => $i,
            'name' => 'Capítulo ' . $i,
            'number' => $i,
            'is_premium' => ($i % 5 === 0),
            'is_current' => ($i == $current_chapter_id)
        );
    }
    
    // Ordenar por número de capítulo (decrescente)
    usort($chapters, function($a, $b) {
        return $b['number'] <=> $a['number'];
    });
    
    return $chapters;
}

// Obter lista de capítulos
$chapters_list = get_manga_chapters_for_select($manga_id, $chapter_id);

// Verificar acesso a capítulos premium
function user_has_premium_access() {
    // Em uma implementação real, isso verificaria se o usuário tem acesso premium
    // Para simulação, vamos considerar administradores e editores como usuários premium
    return current_user_can('administrator') || current_user_can('editor');
}

$has_premium_access = user_has_premium_access();

// Verificar se o capítulo é premium e se o usuário tem acesso
$is_premium_chapter = $chapter_data['is_premium'] ?? false;
$can_access_chapter = !$is_premium_chapter || $has_premium_access;

// Se o usuário não tem acesso, exibir mensagem premium
if (!$can_access_chapter) {
    ?>
    <div class="manga-reader-premium-required">
        <div class="manga-premium-icon">
            <i class="fas fa-crown"></i>
        </div>
        <h2><?php echo esc_html__('Capítulo Premium', 'manga-admin-panel'); ?></h2>
        <p><?php echo esc_html__('Este capítulo está disponível apenas para usuários premium.', 'manga-admin-panel'); ?></p>
        <div class="manga-premium-actions">
            <a href="#" class="manga-btn manga-btn-premium">
                <i class="fas fa-crown"></i> <?php echo esc_html__('Tornar-se Premium', 'manga-admin-panel'); ?>
            </a>
            <a href="<?php echo esc_url($manga_permalink); ?>" class="manga-btn manga-btn-secondary">
                <i class="fas fa-arrow-left"></i> <?php echo esc_html__('Voltar para a lista de capítulos', 'manga-admin-panel'); ?>
            </a>
        </div>
    </div>
    <?php
    return;
}
?>

<div class="manga-reader-container">
    <div class="manga-reader-header">
        <div class="manga-reader-title">
            <h1><?php echo esc_html($manga_title); ?></h1>
            <h2><?php echo esc_html($chapter_data['name']); ?></h2>
        </div>
        
        <div class="manga-reader-controls">
            <div class="manga-reader-setting-group">
                <label for="reader-view-mode"><?php echo esc_html__('Modo de Visualização:', 'manga-admin-panel'); ?></label>
                <select id="reader-view-mode" class="manga-reader-view-mode">
                    <option value="pagination" <?php selected($user_view_mode, 'pagination'); ?>><?php echo esc_html__('Paginado', 'manga-admin-panel'); ?></option>
                    <option value="webtoon" <?php selected($user_view_mode, 'webtoon'); ?>><?php echo esc_html__('Lista Corrida', 'manga-admin-panel'); ?></option>
                </select>
            </div>
            
            <div class="manga-reader-setting-group">
                <label for="reader-brightness"><?php echo esc_html__('Brilho:', 'manga-admin-panel'); ?></label>
                <input type="range" id="reader-brightness" class="manga-reader-brightness" min="50" max="150" value="<?php echo esc_attr($user_brightness); ?>">
                <span class="brightness-value"><?php echo esc_html($user_brightness); ?>%</span>
            </div>
            
            <div class="manga-reader-navigation">
                <div class="manga-chapter-select-wrapper">
                    <select id="chapter-select" class="manga-chapter-select">
                        <?php foreach ($chapters_list as $chapter) : ?>
                            <option value="<?php echo esc_attr($chapter['id']); ?>" <?php selected($chapter['is_current'], true); ?>>
                                <?php echo esc_html($chapter['name']); ?>
                                <?php if ($chapter['is_premium']) : ?>
                                    👑
                                <?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="manga-reader-nav-buttons">
                    <?php if ($chapter_data['prev_chapter']) : ?>
                        <a href="<?php echo esc_url(add_query_arg(array('manga_id' => $manga_id, 'chapter_id' => $chapter_data['prev_chapter']))); ?>" class="manga-reader-nav-btn prev-chapter">
                            <i class="fas fa-chevron-left"></i> <?php echo esc_html__('Capítulo Anterior', 'manga-admin-panel'); ?>
                        </a>
                    <?php endif; ?>
                    
                    <a href="<?php echo esc_url($manga_permalink); ?>" class="manga-reader-nav-btn manga-reader-info">
                        <i class="fas fa-info-circle"></i>
                    </a>
                    
                    <?php if ($chapter_data['next_chapter']) : ?>
                        <a href="<?php echo esc_url(add_query_arg(array('manga_id' => $manga_id, 'chapter_id' => $chapter_data['next_chapter']))); ?>" class="manga-reader-nav-btn next-chapter">
                            <?php echo esc_html__('Próximo Capítulo', 'manga-admin-panel'); ?> <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="manga-reader-content">
        <!-- Modo de visualização paginada -->
        <div id="reader-pagination" class="manga-reader-pagination <?php echo $user_view_mode === 'pagination' ? 'active' : ''; ?>">
            <div class="manga-reader-pages" id="manga-pages-container">
                <?php foreach ($chapter_data['pages'] as $index => $page) : ?>
                    <div class="manga-reader-page <?php echo $index === 0 ? 'active' : ''; ?>" data-page="<?php echo esc_attr($page['id']); ?>">
                        <img src="<?php echo esc_url($page['url']); ?>" alt="<?php echo esc_attr($page['alt']); ?>" loading="lazy">
                        <div class="manga-reader-page-number"><?php echo esc_html($page['id']); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="manga-reader-pagination-controls">
                <button class="manga-reader-page-btn prev-page">
                    <i class="fas fa-chevron-left"></i>
                </button>
                
                <div class="manga-reader-page-counter">
                    <span id="current-page">1</span> / <span id="total-pages"><?php echo count($chapter_data['pages']); ?></span>
                </div>
                
                <button class="manga-reader-page-btn next-page">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        </div>
        
        <!-- Modo de visualização de lista corrida (webtoon) -->
        <div id="reader-webtoon" class="manga-reader-webtoon <?php echo $user_view_mode === 'webtoon' ? 'active' : ''; ?>">
            <?php foreach ($chapter_data['pages'] as $page) : ?>
                <div class="manga-reader-webtoon-image">
                    <img src="<?php echo esc_url($page['url']); ?>" alt="<?php echo esc_attr($page['alt']); ?>" loading="lazy">
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Botão flutuante para voltar ao topo -->
    <button id="back-to-top" class="manga-reader-back-to-top">
        <i class="fas fa-arrow-up"></i>
    </button>
</div>

<script>
jQuery(document).ready(function($) {
    // Variáveis
    let currentPage = 1;
    const totalPages = <?php echo count($chapter_data['pages']); ?>;
    let viewMode = '<?php echo esc_js($user_view_mode); ?>';
    let brightness = <?php echo esc_js($user_brightness); ?>;
    const mangaId = <?php echo esc_js($manga_id); ?>;
    const chapterId = <?php echo esc_js($chapter_id); ?>;
    
    // Inicialização
    updatePageDisplay();
    applyBrightness();
    initializeView();
    
    // Inicializar visualização baseado no modo
    function initializeView() {
        if (viewMode === 'pagination') {
            showActivePage();
        } else {
            // Mostrar botão de voltar ao topo quando necessário
            checkScrollPosition();
        }
    }
    
    // Alternar entre modos de visualização
    $('#reader-view-mode').on('change', function() {
        viewMode = $(this).val();
        
        // Salvar preferência
        saveReaderPreferences();
        
        // Atualizar interface
        if (viewMode === 'pagination') {
            $('#reader-pagination').addClass('active');
            $('#reader-webtoon').removeClass('active');
            showActivePage();
        } else {
            $('#reader-pagination').removeClass('active');
            $('#reader-webtoon').addClass('active');
            checkScrollPosition();
        }
    });
    
    // Ajustar brilho
    $('#reader-brightness').on('input', function() {
        brightness = $(this).val();
        $('.brightness-value').text(brightness + '%');
        applyBrightness();
        
        // Salvar preferência com delay para evitar múltiplas chamadas
        clearTimeout(window.brightnessTimeout);
        window.brightnessTimeout = setTimeout(function() {
            saveReaderPreferences();
        }, 300);
    });
    
    // Salvar preferências do leitor
    function saveReaderPreferences() {
        // Salvar cookies localmente (para persistência imediata)
        document.cookie = 'manga_reader_view_mode=' + viewMode + '; path=/; max-age=31536000';
        document.cookie = 'manga_reader_brightness=' + brightness + '; path=/; max-age=31536000';
        
        // Salvar via AJAX (para usuários logados)
        if (typeof mangaReaderVars !== 'undefined') {
            $.ajax({
                url: mangaReaderVars.ajaxurl,
                type: 'POST',
                data: {
                    action: 'manga_reader_save_preferences',
                    nonce: mangaReaderVars.nonce,
                    view_mode: viewMode,
                    brightness: brightness
                }
            });
        }
    }
    
    // Navegação de páginas
    $('.next-page').on('click', function() {
        if (currentPage < totalPages) {
            currentPage++;
            updatePageDisplay();
            showActivePage();
            saveReadingProgress();
        } else {
            // Se estiver na última página, perguntar se quer ir para o próximo capítulo
            const nextChapterLink = $('.next-chapter').attr('href');
            if (nextChapterLink) {
                if (confirm('<?php echo esc_js(__('Ir para o próximo capítulo?', 'manga-admin-panel')); ?>')) {
                    window.location.href = nextChapterLink;
                }
            }
        }
    });
    
    $('.prev-page').on('click', function() {
        if (currentPage > 1) {
            currentPage--;
            updatePageDisplay();
            showActivePage();
        }
    });
    
    // Navegação por teclado
    $(document).on('keydown', function(e) {
        if (viewMode === 'pagination') {
            if (e.keyCode === 39 || e.keyCode === 40) {
                // Seta direita ou baixo
                $('.next-page').click();
            } else if (e.keyCode === 37 || e.keyCode === 38) {
                // Seta esquerda ou cima
                $('.prev-page').click();
            }
        }
    });
    
    // Alterar capítulo
    $('#chapter-select').on('change', function() {
        const chapterId = $(this).val();
        window.location.href = '<?php echo esc_js(add_query_arg(array('manga_id' => $manga_id, 'chapter_id' => ''))); ?>' + chapterId;
    });
    
    // Botão voltar ao topo
    $('#back-to-top').on('click', function() {
        $('html, body').animate({ scrollTop: 0 }, 300);
    });
    
    // Verificar posição de scroll para mostrar botão voltar ao topo
    $(window).on('scroll', function() {
        checkScrollPosition();
        
        // Salvar progresso baseado na posição do scroll (modo webtoon)
        if (viewMode === 'webtoon') {
            const scrollTop = $(window).scrollTop();
            const windowHeight = $(window).height();
            const docHeight = $(document).height();
            
            // Calcular porcentagem lida
            const percentRead = (scrollTop / (docHeight - windowHeight)) * 100;
            
            // Salvar progresso a cada 20% (para não sobrecarregar o servidor)
            if (percentRead % 20 < 1) {
                saveReadingProgress(percentRead);
            }
        }
    });
    
    // Salvar progresso de leitura
    function saveReadingProgress(percentRead = 0) {
        if (typeof mangaReaderVars !== 'undefined') {
            // Calcular porcentagem lida para o modo paginado
            if (viewMode === 'pagination') {
                percentRead = (currentPage / totalPages) * 100;
            }
            
            $.ajax({
                url: mangaReaderVars.ajaxurl,
                type: 'POST',
                data: {
                    action: 'manga_reader_save_progress',
                    nonce: mangaReaderVars.nonce,
                    manga_id: mangaId,
                    chapter_id: chapterId,
                    page: currentPage,
                    percent_read: percentRead
                }
            });
        }
    }
    
    // Funções auxiliares
    function updatePageDisplay() {
        $('#current-page').text(currentPage);
    }
    
    function showActivePage() {
        $('.manga-reader-page').removeClass('active');
        $(`.manga-reader-page[data-page="${currentPage}"]`).addClass('active');
    }
    
    function applyBrightness() {
        $('.manga-reader-pages img, .manga-reader-webtoon-image img').css('filter', `brightness(${brightness/100})`);
    }
    
    function checkScrollPosition() {
        if ($(window).scrollTop() > 300) {
            $('#back-to-top').addClass('visible');
        } else {
            $('#back-to-top').removeClass('visible');
        }
    }
    
    // Pré-carregar próximas páginas
    function preloadNextPages() {
        if (viewMode === 'pagination') {
            // Pré-carregar as próximas 3 páginas
            for (let i = currentPage + 1; i <= Math.min(currentPage + 3, totalPages); i++) {
                const nextPageImg = new Image();
                nextPageImg.src = $(`.manga-reader-page[data-page="${i}"] img`).attr('src');
            }
        }
    }
    
    // Chamar preload inicial
    preloadNextPages();
    
    // Preload após mudança de página
    $('.next-page, .prev-page').on('click', function() {
        preloadNextPages();
    });
});
</script>

<style>
    /* Reset */
    .manga-reader-container * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }
    
    body.manga-reading {
        overflow-x: hidden;
        background-color: #0D1117;
        transition: background-color 0.3s ease;
    }
    
    .manga-reader-container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 20px;
        background-color: var(--manga-background-color, #f7f7f7);
        overflow: hidden;
        position: relative;
        min-height: 100vh;
    }
    
    /* Header */
    .manga-reader-header {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 20px;
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }
    
    .manga-reader-title {
        text-align: center;
        margin-bottom: 20px;
    }
    
    .manga-reader-title h1 {
        font-size: 24px;
        margin-bottom: 5px;
        color: var(--manga-text-color, #333);
    }
    
    .manga-reader-title h2 {
        font-size: 18px;
        color: var(--manga-light-text, #718093);
        font-weight: normal;
    }
    
    /* Controles */
    .manga-reader-controls {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
    }
    
    .manga-reader-setting-group {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .manga-reader-setting-group label {
        font-size: 14px;
        color: var(--manga-text-color, #333);
    }
    
    .manga-reader-view-mode, 
    .manga-chapter-select {
        padding: 8px 12px;
        border-radius: 4px;
        border: 1px solid #ddd;
        background-color: white;
        font-size: 14px;
        color: var(--manga-text-color, #333);
        cursor: pointer;
    }
    
    .manga-reader-brightness {
        width: 100px;
        cursor: pointer;
    }
    
    .brightness-value {
        font-size: 14px;
        color: var(--manga-light-text, #718093);
        min-width: 40px;
        text-align: right;
    }
    
    .manga-reader-navigation {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 15px;
        width: 100%;
        margin-top: 10px;
    }
    
    .manga-chapter-select-wrapper {
        width: 100%;
        max-width: 300px;
    }
    
    .manga-chapter-select {
        width: 100%;
    }
    
    .manga-reader-nav-buttons {
        display: flex;
        gap: 10px;
        justify-content: center;
        width: 100%;
    }
    
    .manga-reader-nav-btn {
        padding: 8px 15px;
        background-color: var(--manga-primary-color, #ff6b6b);
        color: white;
        text-decoration: none;
        border-radius: 4px;
        font-size: 14px;
        transition: background-color 0.2s;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .manga-reader-nav-btn:hover {
        background-color: #ee5253;
    }
    
    .manga-reader-info {
        padding: 8px;
        border-radius: 50%;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    /* Conteúdo */
    .manga-reader-content {
        position: relative;
    }
    
    /* Modo de visualização paginado */
    .manga-reader-pagination {
        display: none;
        flex-direction: column;
        align-items: center;
    }
    
    .manga-reader-pagination.active {
        display: flex;
    }
    
    .manga-reader-pages {
        width: 100%;
        position: relative;
        max-width: 800px;
        margin: 0 auto;
        border-radius: 5px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        overflow: hidden;
        background-color: #000;
        min-height: 400px;
    }
    
    .manga-reader-page {
        display: none;
        width: 100%;
        height: auto;
        position: relative;
    }
    
    .manga-reader-page.active {
        display: block;
    }
    
    .manga-reader-page img {
        width: 100%;
        height: auto;
        display: block;
    }
    
    .manga-reader-page-number {
        position: absolute;
        bottom: 10px;
        right: 10px;
        background-color: rgba(0,0,0,0.7);
        color: white;
        padding: 3px 8px;
        border-radius: 4px;
        font-size: 12px;
    }
    
    .manga-reader-pagination-controls {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 20px;
        margin-top: 20px;
    }
    
    .manga-reader-page-btn {
        background-color: var(--manga-primary-color, #ff6b6b);
        color: white;
        border: none;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        transition: background-color 0.2s;
    }
    
    .manga-reader-page-btn:hover {
        background-color: #ee5253;
    }
    
    .manga-reader-page-counter {
        font-size: 16px;
        color: var(--manga-text-color, #333);
    }
    
    /* Modo de visualização Webtoon (lista corrida) */
    .manga-reader-webtoon {
        display: none;
        flex-direction: column;
        gap: 5px;
    }
    
    .manga-reader-webtoon.active {
        display: flex;
    }
    
    .manga-reader-webtoon-image {
        max-width: 800px;
        margin: 0 auto;
        width: 100%;
    }
    
    .manga-reader-webtoon-image img {
        width: 100%;
        height: auto;
        display: block;
        border-radius: 5px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    }
    
    /* Botão de voltar ao topo */
    .manga-reader-back-to-top {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background-color: var(--manga-primary-color, #ff6b6b);
        color: white;
        border: none;
        font-size: 20px;
        cursor: pointer;
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 100;
        opacity: 0.8;
        transition: opacity 0.2s, transform 0.2s;
    }
    
    .manga-reader-back-to-top:hover {
        opacity: 1;
        transform: translateY(-3px);
    }
    
    .manga-reader-back-to-top.visible {
        display: flex;
    }
    
    /* Tela de premium */
    .manga-reader-premium-required {
        max-width: 600px;
        margin: 50px auto;
        padding: 30px;
        text-align: center;
        background-color: var(--manga-card-color, #fff);
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .manga-premium-icon {
        font-size: 3rem;
        color: #f1c40f;
        margin-bottom: 20px;
    }
    
    .manga-premium-icon i {
        background: linear-gradient(45deg, #f1c40f, #f39c12);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    .manga-premium-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: center;
        margin-top: 30px;
    }
    
    .manga-btn-premium {
        background: linear-gradient(45deg, #f1c40f, #f39c12);
        color: white;
    }
    
    /* Responsivo */
    @media (max-width: 768px) {
        .manga-reader-controls {
            flex-direction: column;
        }
        
        .manga-reader-setting-group {
            width: 100%;
            justify-content: space-between;
        }
        
        .manga-reader-brightness {
            flex: 1;
        }
        
        .manga-reader-nav-buttons {
            flex-wrap: wrap;
        }
        
        .manga-reader-nav-btn {
            flex: 1;
            text-align: center;
            justify-content: center;
        }
        
        .manga-reader-info {
            flex: 0 0 auto;
        }
    }
</style>