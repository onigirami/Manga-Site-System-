<?php
// Silence is golden.
if (!defined('ABSPATH')) {
    die('Direct access is not allowed.');
}