<?php
/**
 * Plugin Name: Manga Admin Panel
 * Plugin URI: 
 * Description: Uma interface WordPress personalizada para gerenciamento avançado de conteúdo de mangá
 * Version: 1.0.0
 * Author: Manga Admin
 * Text Domain: manga-admin-panel
 */

// Verificação de segurança
if (!defined('ABSPATH')) {
    exit;
}

// Definir constantes
define('MANGA_ADMIN_PANEL_VERSION', '1.0.0');
define('MANGA_ADMIN_PANEL_FILE', __FILE__);
define('MANGA_ADMIN_PANEL_PATH', plugin_dir_path(__FILE__));
define('MANGA_ADMIN_PANEL_URL', plugin_dir_url(__FILE__));

// Função de inicialização com verificação de erros
function manga_admin_panel_init() {
    // Registrar estilos e scripts
    add_action('wp_enqueue_scripts', 'manga_admin_panel_enqueue_scripts');
    
    // Incluir arquivos principais apenas se existirem
    $core_files = array(
        'includes/shortcodes-loader.php',
        'includes/manga-admin-functions.php',
    );
    
    foreach ($core_files as $file) {
        $file_path = MANGA_ADMIN_PANEL_PATH . $file;
        if (file_exists($file_path)) {
            require_once $file_path;
        }
    }
}

// Carregar estilos e scripts
function manga_admin_panel_enqueue_scripts() {
    wp_enqueue_style('manga-admin-styles', MANGA_ADMIN_PANEL_URL . 'assets/css/manga-admin-styles.css', array(), MANGA_ADMIN_PANEL_VERSION);
    wp_enqueue_script('manga-admin-scripts', MANGA_ADMIN_PANEL_URL . 'assets/js/manga-admin-scripts.js', array('jquery'), MANGA_ADMIN_PANEL_VERSION, true);
}

// Inicializar plugin
add_action('plugins_loaded', 'manga_admin_panel_init');

// Shortcode básico de teste
function manga_admin_panel_test_shortcode() {
    return '<div class="manga-admin-test">O plugin Manga Admin Panel está funcionando!</div>';
}
add_shortcode('manga_admin_test', 'manga_admin_panel_test_shortcode');